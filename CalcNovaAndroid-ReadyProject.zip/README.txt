CalcNova offline Android app project.
Upload this folder to a GitHub repository, then open Actions and run 'Build CalcNova AAB'.
The AAB will be available under the workflow's Artifacts section.
